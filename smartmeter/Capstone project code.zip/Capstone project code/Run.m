clc
clear
Code_for_resampling_Wind_data
code_sampling_for_solar
%power_13NodeTestFeeder
load('power_13NodeTestFeeder_initialize.mat')
save('power_13NodeTestFeeder_initialize.mat')