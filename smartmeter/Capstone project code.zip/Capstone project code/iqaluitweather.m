data = readtable('weatherdata.csv');
fieldnames(data);
windspeed=data.("windspeed");
date=data.("datetime");


%temps = [weather.days.temp];

plot(date, windspeed);
legend("Forecast Windspeed");
title(windspeed.description);