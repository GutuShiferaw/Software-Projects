Time=hours(1:1:24);
Time1=transpose(Time);
Wind_Speed=[52.5;52.5;61;59.9;58.7;64.4;70;72.1;69;69;69;68.4;66.8;65;72.2;77.3;63.8;66.4;59.6;55.4;49.9;38.9;40.5;39.7]; % Entre your daily wind speed data here
TT=timetable(Time1,Wind_Speed);
dt=hours(1/60);
TT2WIND=retime(TT,'regular','linear','TimeStep',dt); %resampling the hours data from 24h reading to 1381 samples




