Time_s=hours(1:1:24);
Times1=transpose(Time_s);
solar_rad=[0;0;0;0;0;0;0;0;0;7;24;49;64;66;53;37;18;1;0;0;0;0;0;0]; % Entre your daily wind speed data here
TT2=timetable(Times1,solar_rad);
dt2=hours(1/60);
Solar=retime(TT2,'regular','linear','TimeStep',dt2); %resampling the hours data from 24h reading to 1381 samples




